---
name: multishot-gpt-image-2
description: "Tạo Multishot hoặc Cinematic Storyboard từ ảnh tham chiếu bằng GPT Image với Face Lock và Outfit Lock bắt buộc. Multishot mặc định tạo 9 góc của cùng một khoảnh khắc thành 9 ảnh 9:16 riêng. Khi có từ Video, chuyển sang Storyboard: viết một kịch bản điện ảnh có hành động và cung cảm xúc tiến triển, tạo các keyframe 9:16 nhất quán rồi ghép thành một ảnh lưới duy nhất được đánh số; tỷ lệ toàn tờ được tính theo số hàng/cột. Mặc định 9 ô; số trong lời gọi thay số góc. Sau Storyboard, viết đúng một prompt video tổng hợp cho Omni, Seedance hoặc dùng chung. Khóa gương mặt, tóc, trang phục, phụ kiện, đạo cụ, bối cảnh, chữ/logo, ánh sáng, địa lý cảnh và hướng chuyển động."
---

# Multishot GPT Image 2

Biến ảnh tham chiếu thành nhiều ảnh góc quay riêng biệt, nhất quán và sẵn sàng dùng làm keyframe video.

## Chọn chế độ

- **Mặc định — Multishot:** khi skill được chọn hoặc được gọi và người dùng gửi ảnh mà không có từ `Video`, tạo nhiều góc quay của cùng một khoảnh khắc; chỉ thay vị trí máy, cỡ cảnh và tiêu cự.
- **Có từ Video — Cinematic Storyboard:** khi lời gọi có từ `Video`, chia một câu chuyện/kịch bản duy nhất thành nhiều góc quay liên tiếp và trình bày tất cả góc trong **một ảnh storyboard dạng lưới**. Đánh số từng ô theo đúng trình tự hành động. Sau storyboard, tạo thêm đúng một prompt tổng hợp để biến chuỗi ô thành video.
- **Số lượng:** đọc số nguyên người dùng ghi làm số góc. Nếu không có số, mặc định 9 góc trong cả hai chế độ.
- **Nền tảng video:** nếu có `Omni` hoặc `Seedance`, tối ưu prompt cho nền tảng đó; nếu không có, viết prompt trung tính dùng được cho cả hai.

Từ `Video` là công tắc chọn Storyboard. Không có `Video` thì luôn dùng Multishot, kể cả khi người dùng không gõ tên chế độ. Không hỏi lại khi quy tắc này đã xác định được chế độ.

## Cách gọi tối giản

Sau khi chọn skill và đính kèm ảnh, phần chữ có thể để trống hoặc chỉ cần ghi:

- Không ghi gì → Multishot, 9 góc quay thành 9 ảnh riêng.
- `6` → Multishot, đúng 6 góc quay thành 6 ảnh riêng.
- `Video` → một ảnh Storyboard lưới 9 ô đánh số 1–9 và 1 prompt video tổng hợp dùng chung.
- `Video 6` → một ảnh Storyboard lưới 6 ô đánh số 1–6 và 1 prompt video tổng hợp dùng chung.
- `Video Seedance` → một ảnh Storyboard lưới 9 ô và 1 prompt tối ưu cho Seedance.
- `Video 6 Seedance` → một ảnh Storyboard lưới 6 ô và 1 prompt tối ưu cho Seedance.
- `Video 8 Omni` → một ảnh Storyboard lưới 8 ô và 1 prompt tối ưu cho Omni.
- Nội dung còn lại sau `Video`, số lượng và tên nền tảng là yêu cầu câu chuyện. Ví dụ: `Video 6 Seedance cô gái trải nghiệm sản phẩm`.

## Số lượng và định dạng đầu ra

- Dùng đúng số góc người dùng yêu cầu. Nếu không ghi số, mặc định 9 góc.
- Chấp nhận số lượng linh hoạt. Với bộ lớn, vẫn duy trì một kế hoạch chung và tạo theo từng đợt nếu công cụ giới hạn số ảnh.
- **Multishot:** xuất mỗi góc quay thành một ảnh dọc 9:16 riêng. Không tạo contact sheet, collage, grid hoặc split-screen; không chèn số lên ảnh.
- **Storyboard/Video:** xuất đúng một ảnh storyboard. Chia ảnh thành lưới rõ ràng chứa đúng số ô được yêu cầu; mặc định 9 ô theo bố cục 3×3. Mỗi ô là một góc quay hoặc khoảnh khắc kế tiếp của cùng câu chuyện và phải có số thứ tự dễ đọc ở góc ô: `1`, `2`, `3`... Không xuất các ô thành ảnh riêng trừ khi người dùng yêu cầu thêm.
- Với số không tạo được lưới vuông, chọn bố cục cân đối theo thứ tự đọc trái sang phải, trên xuống dưới; ví dụ 6 ô dùng 3×2, 8 ô dùng 4×2 hoặc 2×4 tùy tỷ lệ.
- Khóa tỷ lệ **từng ô Storyboard là 9:16**. Tính tỷ lệ toàn tờ theo công thức `(số cột × 9):(số hàng × 16)`. Ví dụ: 6 ô 3×2 → `27:32`; 9 ô 3×3 → `9:16`; không ép tờ 6 ô thành 9:16 vì sẽ làm sai tỷ lệ từng khung phim.
- Không thêm caption dài, watermark hoặc chữ mới ngoài số thứ tự của các ô Storyboard.

## Quy tắc thực thi

- Có ảnh rõ thì tạo ngay; không hỏi xác nhận lại.
- Chưa có ảnh thì chỉ yêu cầu tải ảnh tham chiếu.
- Dùng công cụ tạo/chỉnh sửa ảnh với mô hình GPT Image tốt nhất hiện có. Không chỉ viết prompt nếu người dùng yêu cầu tạo ảnh.
- Tạo toàn bộ kế hoạch góc quay trước. Với Multishot, sinh từng ảnh riêng. Với Storyboard, sinh một ảnh lưới duy nhất chứa toàn bộ kế hoạch và số thứ tự hành động.
- Dùng lại ảnh tham chiếu gốc và cùng một khóa liên tục cho mọi lần sinh. Khi hữu ích, dùng thêm ảnh liền trước làm tham chiếu diễn biến nhưng không để ảnh sau trôi khỏi nhận diện gốc.
- Không hứa giống tuyệt đối; tối đa hóa độ trung thực bằng khóa chi tiết và tối đa một lượt sửa lỗi có mục tiêu cho mỗi ảnh lỗi.

## Phân vai ảnh đầu vào

- Một ảnh: dùng làm neo nhân vật, trang phục, vật thể và bối cảnh.
- Nhiều ảnh không ghi vai trò: dùng Ảnh 1 làm neo nhận diện; dùng các ảnh sau làm tham chiếu sản phẩm, trang phục hoặc phong cách theo nội dung nhìn thấy.
- Khi xung đột, ưu tiên: yêu cầu hiện tại → nhận diện từ Ảnh 1 → sản phẩm/logo/chữ từ ảnh sản phẩm → phong cách.
- Chỉ hỏi một câu nếu không thể xác định ảnh nhân vật hoặc sản phẩm và lựa chọn sai làm thay đổi đáng kể kết quả.

## Khóa tính liên tục

Trước khi tạo, phân tích nội bộ và lập một `continuity anchor` gồm:

- nhận diện khuôn mặt và đặc điểm nhìn thấy;
- tóc, trang điểm, trang phục, màu, chất liệu, họa tiết;
- chữ, logo, nhãn và cách viết chính xác;
- phụ kiện, sản phẩm, đạo cụ, số lượng và tay đang cầm;
- địa hình, kiến trúc, mặt nước, đường chân trời, nguồn sáng, thời tiết và bảng màu;
- vị trí tương đối của nhân vật, vật thể và nguồn sáng;
- hướng nhìn, hướng di chuyển và trục máy.

Lặp lại các yếu tố khóa trong mọi lần sinh. Khi góc mới phải dựng vùng khuất, suy diễn tối thiểu. Không đảo gương chữ hoặc logo.

### Face Lock và Outfit Lock bắt buộc

- Dùng ảnh tham chiếu gốc làm neo nhận diện chính cho **mọi** góc, không dùng một ảnh sinh trung gian thay thế neo gốc.
- Khóa cấu trúc khuôn mặt, mắt, mũi, môi, đường hàm, tông da và đặc điểm nhận diện nhìn thấy. Chỉ thay biểu cảm theo diễn biến kịch bản; không thay danh tính.
- Khóa toàn bộ tóc, kiểu tóc, trang phục, màu, chất liệu, đường cắt, họa tiết, lớp trong/lớp ngoài, phụ kiện và cách mặc. Không tự đổi trang phục để phù hợp góc máy.
- Với chữ hoặc logo trong bối cảnh, giữ đúng cách viết, màu và vị trí; không đảo gương hoặc tự sửa tên.
- Sau khi sinh, so từng góc với ảnh gốc. Nếu trôi mặt hoặc đổi trang phục, loại góc đó và sửa tối đa một lần có mục tiêu trước khi ghép Storyboard.

## Multishot: cùng khoảnh khắc, nhiều góc quay

Chọn đúng số lượng góc từ thư viện sau, tránh trùng lặp:

- extreme wide establishing;
- wide/full-body eye level;
- medium frontal;
- medium three-quarter;
- close-up;
- extreme close-up chi tiết;
- over-the-shoulder;
- rear three-quarter;
- low-angle hero;
- high-angle;
- top-down;
- side profile.

Nêu rõ `same subject, same action, same moment, same location`. Chỉ đổi góc máy, cỡ cảnh, khoảng cách và tiêu cự.

## Storyboard: một kịch bản, nhiều góc quay

### Dựng kịch bản

Nếu người dùng chưa đưa nội dung, tự dựng một kịch bản ngắn phù hợp nhân vật, địa điểm, thời tiết, ánh sáng và tâm trạng gợi ra từ ảnh. Tóm tắt nội bộ câu chuyện bằng một câu có `nhân vật + mong muốn + chuyển biến cảm xúc`, rồi chia thành đúng số góc được yêu cầu.

- 3 góc: mở đầu → phát triển → kết.
- 4–5 góc: mở không gian → giới thiệu → hành động → điểm nhấn → kết; rút gọn tương ứng.
- 6 góc trở lên: mở không gian → giới thiệu → khởi phát → chi tiết → phát triển → tương tác → điểm nhấn → hạ nhịp → kết; co giãn số nhịp cho đúng số lượng.

Mỗi ô phải là một **nhịp hành động mới** trong cùng kịch bản, không chỉ là một góc máy mới. Xây cung cảm xúc nhìn thấy được qua ánh mắt, biểu cảm, tư thế, khoảng cách với đạo cụ và ánh sáng: trạng thái ban đầu → tác nhân → phản ứng → thay đổi → điểm nhấn → dư âm. Không tạo nhiều câu chuyện riêng, bộ ảnh tạo dáng rời rạc hoặc cùng một hành động được nhìn từ nhiều góc; đó là Multishot, không phải Storyboard.

Trước khi sinh, kiểm tra từng ô bằng hai câu: `Hành động mới là gì?` và `Cảm xúc đã chuyển thế nào?`. Nếu hai câu không có đáp án khác ô trước, phải viết lại nhịp đó.

### Điều phối điện ảnh

- Phối hợp EWS, WS, MS, MCU, CU, ECU, OTS, high angle, low angle và top-down khi phù hợp.
- Không lặp cùng cỡ cảnh quá hai lần liên tiếp.
- Giữ trục 180 độ, hướng nhìn và hướng di chuyển nhất quán.
- Tạo nhịp rộng → trung → cận → động → điểm nhấn → kết; tránh toàn bộ ảnh đều là chân dung.
- Dùng 24–35mm cho không gian, 50mm cho trung cảnh và 85mm cho cận cảnh khi phù hợp.
- Giữ địa lý cảnh, ánh sáng, đạo cụ, sản phẩm và trạng thái hành động liên tục giữa các góc.

## Sinh ảnh đầu ra

Với Multishot, đưa vào từng lệnh sinh:

- số góc và vai trò của nó trong kế hoạch;
- `continuity anchor` đầy đủ;
- hành động, biểu cảm, vị trí nhân vật và sản phẩm;
- cỡ cảnh, góc máy, tiêu cự, độ sâu trường ảnh và bố cục;
- ràng buộc: ảnh đơn 9:16, không collage, không split-screen, không số, không caption, không watermark, không thêm người/vật thể, không đổi nhận diện/trang phục/logo/chữ.

Với Storyboard, ưu tiên quy trình hai bước để khóa tỷ lệ và nhận diện:

1. Sinh từng keyframe trung gian riêng ở tỷ lệ 9:16. Trong **mỗi** lệnh, dùng lại ảnh tham chiếu gốc, lặp lại Face Lock, Outfit Lock, bối cảnh khóa, hành động mới, cảm xúc, cỡ cảnh và quan hệ nhân quả của góc đó.
2. Kiểm tra nhận diện và trang phục, rồi ghép keyframe bằng công cụ bố cục chính xác thành **một ảnh Storyboard cuối**. Giữ mỗi ô nguyên tỷ lệ 9:16, dùng đường phân cách gọn và đánh số theo thứ tự đọc trái sang phải, trên xuống dưới.

Không hiển thị hoặc bàn giao các keyframe trung gian trừ khi người dùng yêu cầu; đầu ra Storyboard là một tờ lưới duy nhất. Không nhờ mô hình ảnh tự dàn toàn bộ lưới nếu việc đó làm sai tỷ lệ từng ô.

## Tạo một prompt video tổng hợp

Sau khi hoàn thành Cinematic Storyboard, tự động viết **đúng một prompt video duy nhất** dùng các ô được đánh số theo thứ tự. Không viết một prompt riêng cho từng ô trừ khi người dùng yêu cầu.

- Nếu người dùng chọn **Omni**, viết prompt chỉ rõ `Panel 1`, `Panel 2`... là các keyframe theo trình tự thời gian; mô tả cách chuyển giữa chúng, hành động liên tục, camera motion, nhịp dựng, âm thanh và tỷ lệ.
- Nếu người dùng chọn **Seedance**, viết prompt multishot có `SHOT 1`, `SHOT 2`...; nêu hành động, camera motion, chuyển cảnh/hard cut, nhịp thời gian và continuity cho toàn bộ video.
- Nếu không chọn nền tảng, viết một prompt trung tính tương thích cả Omni và Seedance, dùng cấu trúc `SHOT 1...N` và nói rõ các ô tham chiếu theo đúng thứ tự.
- Mặc định prompt video bằng tiếng Anh kỹ thuật để mô hình dễ hiểu. Chỉ thêm thoại khi người dùng yêu cầu; nếu có thoại, giữ đúng ngôn ngữ người dùng chọn.
- Khóa nhân vật, tóc, trang phục, phụ kiện, sản phẩm, logo, bối cảnh, ánh sáng và hướng chuyển động. Cấm face drift, outfit drift, object duplication, morphing, flicker, warped hands và chữ/logo biến dạng.
- Dùng tỷ lệ 9:16 và nhịp điện ảnh tự nhiên. Không tự áp đặt thời lượng vượt giới hạn của nền tảng; dùng thời lượng người dùng yêu cầu hoặc phân bổ trong giới hạn hiện có.

## Kiểm tra chất lượng

- Multishot có đủ đúng số ảnh riêng đã yêu cầu và không có ảnh lưới.
- Storyboard có đúng một ảnh lưới, đủ số ô đã yêu cầu, đánh số đúng thứ tự hành động và không xuất thành các ảnh riêng.
- Mỗi ô Storyboard đúng tỷ lệ 9:16; tỷ lệ toàn tờ đúng với bố cục lưới, không làm méo hoặc kéo dài khung phim.
- Cùng nhân vật và đúng toàn bộ yếu tố khóa trong mọi ảnh.
- Gương mặt khớp ảnh tham chiếu ở mọi ô; chỉ biểu cảm thay đổi. Tóc, trang phục, màu, chất liệu, phụ kiện và cách mặc không đổi giữa các ô.
- Không thêm tay, chân, người, sản phẩm hoặc phụ kiện.
- Chữ/logo không sai hoặc đảo gương.
- Multishot có các góc thực sự khác nhau.
- Storyboard kể rõ một kịch bản, hành động tiến triển và không nhảy trục.
- Storyboard có cung cảm xúc phù hợp bối cảnh; mỗi ô có hành động và trạng thái cảm xúc khác ô trước, không biến thành Multishot.
- Nếu là Storyboard, có đúng một prompt video tổng hợp sau ảnh lưới.

## Câu gọi mẫu

- Chọn skill + gửi ảnh, không cần gõ gì → Multishot 9 góc.
- `6`
- `Video`
- `Video 6`
- `Video 6 Seedance`
- `Video 8 Omni`
